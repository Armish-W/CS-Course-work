CREATE DATABASE hospital;
USE hospital;

CREATE TABLE patients
 (
    patient_id INT PRIMARY KEY,
    patient_name VARCHAR(100),
    patient_contact VARCHAR(15),
    age INT,
    gender CHAR(1),
    comorbidity_index INT
);

CREATE TABLE Doctors 
(
    doctor_id INT PRIMARY KEY,
    doctor_name VARCHAR(100),
    doctor_specialty VARCHAR(100)
);

CREATE TABLE Nurses 
(
    nurse_id INT PRIMARY KEY,
    nurse_name VARCHAR(100)
);

CREATE TABLE Ward
(
    ward_id VARCHAR(10) PRIMARY KEY,
    ward_type VARCHAR(100),
    hospital_location VARCHAR(100)
);
    
CREATE TABLE Admissions
(
    admission_id INT PRIMARY KEY,
    patient_id INT,
    doctor_id INT,
    nurse_id INT,
    ward_id VARCHAR(10),
    admission_type VARCHAR(50),
    baseline_risk_score DECIMAL(5,4),
    los_hours INT,
    deterioration_event INT,
    deterioration_within_12h_from_admission INT,
    deterioration_hour INT,
    -- Foreign Keys
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id),
    FOREIGN KEY (nurse_id) REFERENCES Nurses(nurse_id),
    FOREIGN KEY (ward_id) REFERENCES Ward(ward_id)
);

CREATE TABLE vitals_readings 
(
    vital_id INT PRIMARY KEY,
    admission_id INT,
    hour_from_admission INT,
    heart_rate DECIMAL(5,2),
    respiratory_rate DECIMAL(5,2),
    spo2_pct DECIMAL(5,2),
    temperature_c DECIMAL(4,2),
    systolic_bp DECIMAL(6,2),
    diastolic_bp DECIMAL(6,2),
    oxygen_device VARCHAR(50),
    oxygen_flow DECIMAL(5,2),
    mobility_score INT,
    nurse_alert INT,
    -- Foreign Key
    FOREIGN KEY (admission_id) REFERENCES Admissions(admission_id)
);
CREATE TABLE vitals_readings 
(
    vital_id INT PRIMARY KEY,

    admission_id INT,

    hour_from_admission INT,
    heart_rate DECIMAL(5,2),
    respiratory_rate DECIMAL(5,2),
    spo2_pct DECIMAL(5,2),
    temperature_c DECIMAL(4,2),
    systolic_bp DECIMAL(6,2),
    diastolic_bp DECIMAL(6,2),
    oxygen_device VARCHAR(50),
    oxygen_flow DECIMAL(5,2),
    mobility_score INT,
    nurse_alert TINYINT,
    -- Foreign Key
    FOREIGN KEY (admission_id) REFERENCES Admissions(admission_id)
);

CREATE TABLE lab_readings 
(
    lab_id INT PRIMARY KEY,
    admission_id INT,
    hour_from_admission INT,
    wbc_count DECIMAL(6,2),
    lactate DECIMAL(5,2),
    creatinine DECIMAL(5,2),
    crp_level DECIMAL(6,2),
    hemoglobin DECIMAL(5,2),
    sepsis_risk_score DECIMAL(5,4),
    deterioration_next_12h iNT,
    -- Foreign Key
    FOREIGN KEY (admission_id) REFERENCES Admissions(admission_id)
);


INSERT INTO patients 
(patient_id, patient_name, patient_contact, age, gender, comorbidity_index)
VALUES
(1, 'Ali', 301, 24, 'M', 2),
(2, 'Amna', 302, 74, 'F', 3),
(3, 'Usman', 303, 65, 'M', 7),
(4, 'Afra', 402, 50, 'F', 0),
(5, 'Amna', 333, 49, 'F', 0),
(6, 'Abeeha', 124, 80, 'F', 2),
(7, 'Muaz', 567, 24, 'M', 5),
(8, 'Sara', 453, 68, 'F', 7),
(9, 'Zara', 123, 32, 'F', 5),
(10, 'Aleena', 876, 24, 'F', 4),
(11, 'Ahmed', 343, 56, 'M', 7),
(12, 'Faris', 300, 89, 'M', 1),
(13, 'Saad', 290, 71, 'M', 8),
(14, 'Hamza', 340, 73, 'M', 2),
(15, 'Awais', 540, 70, 'M', 2),
(16, 'Zara', 129, 75, 'F', 8),
(17, 'Hamna', 321, 55, 'F', 5),
(18, 'Ayesha', 676, 27, 'F', 3),
(19, 'Dua', 231, 79, 'F', 2),
(20, 'Azka', 120, 50, 'F', 3),
(21, 'Amna', 319, 54, 'F', 7),
(22, 'Samra', 718, 45, 'F', 1),
(23, 'Sara', 401, 31, 'F', 1),
(24, 'Zahir', 359, 85, 'M', 2),
(25, 'Zafar', 151, 75, 'M', 4),
(26, 'Huma', 283, 65, 'F', 7),
(27, 'Shafaq', 152, 47, 'F', 1),
(28, 'Huda', 951, 78, 'F', 7),
(29, 'Kehmish', 666, 57, 'F', 8),
(30, 'Ali', 198, 50, 'M', 3),
(31, 'Ahmer', 999, 50, 'M', 8),
(32, 'Shery', 543, 34, 'M', 8),
(33, 'Zohaib', 922, 24, 'M', 7),
(34, 'Abbas', 101, 58, 'M', 3),
(35, 'Maida', 560, 82, 'F', 2),
(36, 'Alizay', 307, 22, 'F', 7),
(37, 'Zainab', 271, 80, 'F', 3),
(38, 'Fatima', 576, 78, 'F', 0),
(39, 'Aliha', 992, 38, 'F', 6),
(40, 'Nimra', 171, 64, 'F', 3),
(41, 'Farwa', 232, 30, 'F', 8),
(42, 'Misma', 898, 73, 'F', 7),
(43, 'Abdullah', 561, 69, 'M', 0),
(44, 'Awais', 560, 43, 'M', 8),
(45, 'Ali', 323, 22, 'M', 8),
(46, 'Musa', 444, 88, 'M', 6),
(47, 'Muaz', 888, 50, 'M', 2),
(48, 'Amir', 111, 83, 'M', 6),
(49, 'Asim', 200, 67, 'M', 7)
;

INSERT INTO doctors 
(doctor_id, doctor_name, doctor_specialty)
VALUES
(102, 'Dr. Humza', 'Internal Medicine'),
(103, 'Dr. Talha', 'Emergency')
;

INSERT INTO nurses 
(nurse_id, nurse_name)
VALUES
(502, 'nurse_Amna'),
(503, 'nurse_Nimra')
;

INSERT INTO ward 
(ward_id, ward_type, hospital_location) 
VALUES
('W-B', 'General', 'Mid City Hospital'),
('W-C', 'Emergency Room', 'Mid City Hospital')
;

INSERT INTO admissions 
(admission_id, patient_id, doctor_id, nurse_id, ward_id, admission_type,
 baseline_risk_score, los_hours, deterioration_event, deterioration_within_12h_from_admission, deterioration_hour) 
 VALUES
(201, 1, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(202, 2, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(203, 3, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(204, 4, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(205, 5, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(206, 6, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(207, 7, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(208, 8, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(209, 9, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(210, 10, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(211, 11, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(212, 12, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(213, 13, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(214, 14, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(215, 15, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(216, 16, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(217, 17, 102, 502, 'W-B', 'Elective', 0.2173, 17, 0, 0, -1),
(218, 18, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(219, 19, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(220, 20, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(221, 21, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(222, 22, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(223, 23, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(224, 24, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(225, 25, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(226, 26, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(227, 27, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(228, 28, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(229, 29, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(230, 30, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(231, 31, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(232, 32, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(233, 33, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(234, 34, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(235, 35, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(236, 36, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(237, 37, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(238, 38, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(239, 39, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(240, 40, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(241, 41, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(242, 42, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(243, 43, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(244, 44, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(245, 45, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(246, 46, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(247, 47, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(248, 48, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16),
(249, 49, 103, 503, 'W-C', 'Transfer', 0.5558, 33, 1, 0, 16)
;

INSERT INTO vitals_readings (vital_id, admission_id, hour_from_admission, heart_rate, respiratory_rate, spo2_pct, temperature_c, systolic_bp, diastolic_bp, oxygen_device, oxygen_flow, mobility_score, nurse_alert) VALUES
(301, 201, 0, 68.58, 14.47, 96.52, 37.18, 108.94, 78.43, 'none', 0.0, 2, 0),
(302, 202, 1, 67.03, 13.87, 94.94, 37.25, 111.73, 79.14, 'none', 0.0, 3, 0),
(303, 203, 2, 69.05, 14.63, 94.45, 37.29, 111.48, 78.86, 'none', 0.0, 2, 0),
(304, 204, 3, 69.07, 14.42, 95.16, 37.27, 110.68, 76.79, 'none', 0.0, 2, 0),
(305, 205, 4, 73.35, 15.62, 95.83, 37.21, 110.38, 75.47, 'none', 0.0, 3, 0),
(306, 206, 5, 73.39, 15.44, 94.21, 37.28, 109.26, 75.58, 'none', 0.0, 2, 0),
(307, 207, 6, 74.22, 15.37, 94.37, 37.24, 108.75, 74.17, 'none', 0.0, 3, 0),
(308, 208, 7, 73.4, 15.12, 94.83, 37.21, 108.9, 71.97, 'none', 0.0, 3, 0),
(309, 209, 8, 73.35, 14.06, 94.53, 37.23, 106.08, 71.13, 'none', 0.0, 1, 1),
(310, 210, 9, 71.29, 12.98, 94.79, 37.1, 107.75, 72.03, 'none', 0.0, 2, 0),
(311, 211, 10, 73.85, 13.32, 94.61, 37.13, 106.28, 73.31, 'none', 0.0, 3, 0),
(312, 212, 11, 73.96, 14.03, 94.36, 37.14, 106.19, 73.2, 'none', 0.0, 2, 0),
(313, 213, 12, 76.29, 12.85, 93.55, 37.18, 105.62, 72.87, 'none', 0.0, 3, 0),
(314, 214, 13, 75.7, 14.13, 94.01, 37.17, 105.63, 73.19, 'none', 0.0, 3, 0),
(315, 215, 14, 74.26, 15.2, 94.02, 37.25, 108.07, 72.03, 'none', 0.0, 2, 0),
(316, 216, 15, 74.18, 15.15, 94.35, 37.32, 108.59, 71.49, 'none', 0.0, 3, 0),
(317, 217, 16, 75.06, 14.86, 94.18, 37.35, 107.12, 70.86, 'none', 0.0, 3, 0),
(318, 218, 0, 81.4, 21.2, 95.66, 36.98, 105.55, 66.57, 'none', 0.0, 4, 0),
(319, 219, 1, 82.88, 20.95, 95.83, 36.96, 104.72, 65.91, 'none', 0.0, 3, 0),
(320, 220, 2, 81.81, 20.34, 96.8, 36.96, 104.57, 66.85, 'none', 0.0, 2, 0),
(321, 221, 3, 82.44, 20.39, 97.38, 37.02, 104.63, 67.38, 'none', 0.0, 3, 0),
(322, 222, 4, 79.52, 20.93, 97.12, 37.07, 105.49, 68.71, 'none', 0.0, 3, 0),
(323, 223, 5, 79.58, 20.75, 97.7, 37.07, 104.78, 70.11, 'none', 0.0, 2, 0),
(324, 224, 6, 77.74, 20.96, 97.36, 37.05, 103.21, 70.26, 'none', 0.0, 3, 0),
(325, 225, 7, 75.32, 20.54, 97.04, 37.09, 102.15, 69.54, 'none', 0.0, 3, 0),
(326, 226, 8, 75.95, 21.9, 96.08, 36.99, 100.0, 67.07, 'none', 0.0, 3, 0),
(327, 227, 9, 70.0, 22.35, 96.04, 37.08, 100.84, 67.22, 'none', 0.0, 2, 0),
(328, 228, 10, 72.7, 22.68, 96.09, 37.11, 99.57, 66.67, 'none', 0.0, 1, 0),
(329, 229, 11, 73.29, 23.46, 96.04, 37.17, 95.51, 65.43, 'none', 0.0, 1, 0),
(330, 230, 12, 76.24, 23.88, 95.21, 37.18, 92.91, 66.04, 'none', 0.0, 3, 0),
(331, 231, 13, 76.56, 24.38, 94.27, 37.19, 88.73, 62.84, 'none', 0.0, 3, 1),
(332, 232, 14, 76.13, 25.42, 94.35, 37.17, 85.62, 60.53, 'none', 0.0, 2, 0),
(333, 233, 15, 77.92, 26.23, 93.41, 37.2, 83.63, 58.35, 'none', 0.0, 1, 1),
(334, 234, 16, 81.06, 27.33, 93.02, 37.24, 79.81, 58.55, 'none', 0.0, 2, 1),
(335, 235, 17, 85.18, 26.54, 92.79, 37.27, 80.69, 56.77, 'none', 0.0, 1, 1),
(336, 236, 18, 84.49, 25.07, 91.92, 37.26, 79.64, 55.47, 'none', 0.0, 0, 0),
(337, 237, 19, 85.56, 25.91, 90.7, 37.38, 76.72, 55.08, 'nasal', 0.79, 1, 1),
(338, 238, 20, 87.3, 27.95, 90.67, 37.4, 77.3, 53.13, 'mask', 10.3, 0, 1),
(339, 239, 21, 90.18, 28.21, 89.0, 37.47, 76.0, 51.87, 'hfnc', 35.56, 2, 1),
(340, 240, 22, 90.65, 27.99, 88.12, 37.48, 74.32, 50.22, 'niv', 51.21, 0, 1),
(341, 241, 23, 92.26, 30.35, 86.77, 37.69, 72.05, 47.84, 'niv', 48.11, 1, 1),
(342, 242, 24, 98.36, 31.75, 86.15, 37.73, 70.0, 47.01, 'niv', 51.98, 1, 1),
(343, 243, 25, 102.04, 32.27, 85.42, 37.73, 70.0, 46.89, 'niv', 52.12, 0, 1),
(344, 244, 26, 105.68, 33.51, 83.92, 37.81, 70.0, 44.26, 'niv', 49.23, 0, 1),
(345, 245, 27, 113.43, 34.11, 83.37, 37.93, 70.0, 41.85, 'niv', 50.52, 0, 1),
(346, 246, 28, 115.24, 36.01, 81.99, 38.05, 70.0, 40.98, 'niv', 50.88, 0, 1),
(347, 247, 29, 120.75, 37.1, 80.85, 38.08, 70.0, 40.0, 'niv', 48.76, 1, 1),
(348, 248, 30, 124.89, 37.51, 80.0, 38.1, 70.0, 40.0, 'niv', 49.33, 1, 1),
(349, 249, 31, 128.22, 39.26, 78.7, 38.07, 70.0, 40.0, 'niv', 50.42, 0, 1)
;

INSERT INTO lab_readings 
(lab_id, admission_id, hour_from_admission, wbc_count, lactate, creatinine, 
crp_level, hemoglobin, sepsis_risk_score, deterioration_next_12h) 
VALUES
(401, 201, 0, 5.68, 1.28, 1.27, 10.66, 13.55, 0.2621, 0),
(402, 202, 1, 5.46, 1.18, 1.22, 11.94, 13.65, 0.3353, 0),
(403, 203, 2, 5.55, 1.21, 1.25, 10.24, 13.69, 0.1678, 0),
(404, 204, 3, 5.50, 1.13, 1.24, 10.72, 13.61, 0.1961, 0),
(405, 205, 4, 5.96, 1.20, 1.21, 11.46, 13.49, 0.3000, 0),
(406, 206, 5, 6.53, 1.10, 1.21, 12.45, 13.58, 0.3197, 0),
(407, 207, 6, 6.42, 1.19, 1.22, 13.07, 13.45, 0.3819, 0),
(408, 208, 7, 6.34, 1.30, 1.23, 14.87, 13.53, 0.5769, 0),
(409, 209, 8, 6.26, 1.31, 1.28, 16.24, 13.44, 0.8892, 0),
(410, 210, 9, 6.14, 1.38, 1.25, 14.56, 13.48, 0.3208, 0),
(411, 211, 10, 6.38, 1.54, 1.23, 12.70, 13.52, 0.3322, 0),
(412, 212, 11, 6.84, 1.43, 1.23, 12.81, 13.58, 0.2139, 0),
(413, 213, 12, 6.77, 1.51, 1.21, 14.00, 13.48, 0.4385, 0),
(414, 214, 13, 6.67, 1.56, 1.23, 11.77, 13.45, 0.3111, 0),
(415, 215, 14, 6.55, 1.52, 1.24, 13.22, 13.46, 0.2930, 0),
(416, 216, 15, 6.92, 1.56, 1.24, 15.28, 13.48, 0.7849, 0),
(417, 217, 16, 6.92, 1.66, 1.24, 15.41, 13.40, 0.6947, 0),
(418, 218, 0, 7.03, 1.53, 1.05, 24.94, 12.34, 0.4210, 0),
(419, 219, 1, 7.46, 1.50, 1.09, 24.12, 12.30, 0.4801, 0),
(420, 220, 2, 7.25, 1.59, 1.09, 21.41, 12.25, 0.2497, 0),
(421, 221, 3, 6.91, 1.65, 1.10, 23.41, 12.23, 0.3737, 0),
(422, 222, 4, 7.19, 1.74, 1.14, 25.17, 12.17, 0.2644, 1),
(423, 223, 5, 7.18, 1.73, 1.13, 25.93, 12.14, 0.3890, 1),
(424, 224, 6, 6.89, 1.78, 1.12, 27.64, 12.17, 0.4677, 1),
(425, 225, 7, 6.75, 1.82, 1.14, 25.61, 12.12, 0.1783, 1),
(426, 226, 8, 6.65, 1.90, 1.16, 28.22, 12.14, 0.3958, 1),
(427, 227, 9, 6.66, 1.88, 1.17, 30.90, 12.16, 0.6283, 1),
(428, 228, 10, 6.55, 1.93, 1.22, 33.65, 12.19, 0.6414, 1),
(429, 229, 11, 6.69, 2.05, 1.31, 33.14, 12.10, 0.4245, 1),
(430, 230, 12, 7.26, 2.04, 1.36, 33.48, 12.07, 0.4931, 1),
(431, 231, 13, 7.29, 2.14, 1.36, 34.89, 11.98, 0.5159, 1),
(432, 232, 14, 7.47, 2.35, 1.46, 39.64, 11.95, 0.5784, 1),
(433, 233, 15, 8.08, 2.68, 1.53, 43.83, 11.95, 0.6140, 1),
(434, 234, 16, 8.34, 2.86, 1.59, 44.38, 11.85, 0.7563, 0),
(435, 235, 17, 8.80, 3.14, 1.66, 45.63, 11.57, 0.9516, 0),
(436, 236, 18, 9.35, 3.39, 1.74, 48.71, 11.40, 0.5909, 0),
(437, 237, 19, 10.10, 3.59, 1.85, 52.35, 11.21, 0.6224, 0),
(438, 238, 20, 10.45, 3.91, 1.99, 57.52, 11.16, 0.8529, 0),
(439, 239, 21, 11.32, 4.15, 2.09, 60.70, 11.06, 0.8987, 0),
(440, 240, 22, 12.40, 4.55, 2.17, 65.76, 11.01, 0.8117, 0),
(441, 241, 23, 12.63, 5.00, 2.28, 73.15, 11.08, 0.9535, 0),
(442, 242, 24, 13.51, 5.30, 2.39, 74.52, 10.95, 0.8745, 0),
(443, 243, 25, 13.90, 5.54, 2.48, 84.00, 10.78, 0.9028, 0),
(444, 244, 26, 14.42, 5.89, 2.62, 89.93, 10.66, 0.9072, 0),
(445, 245, 27, 15.11, 6.21, 2.80, 96.65, 10.52, 0.9927, 0),
(446, 246, 28, 15.73, 6.65, 2.93, 96.12, 10.34, 0.9836, 0),
(447, 247, 29, 16.53, 7.04, 3.05, 103.00, 10.24, 0.9946, 0),
(448, 248, 30, 17.13, 7.35, 3.17, 109.08, 10.03, 0.9935, 0),
(449, 249, 31, 17.82, 7.61, 3.27, 113.58, 9.87, 0.9892, 0)
;

-- Drop the first vitals_readings table if both exist
DROP TABLE IF EXISTS vitals_readings;

-- Then create the corrected version (with TINYINT)
CREATE TABLE vitals_readings 
(
    vital_id INT PRIMARY KEY,
    admission_id INT,
    hour_from_admission INT,
    heart_rate DECIMAL(5,2),
    respiratory_rate DECIMAL(5,2),
    spo2_pct DECIMAL(5,2),
    temperature_c DECIMAL(4,2),
    systolic_bp DECIMAL(6,2),
    diastolic_bp DECIMAL(6,2),
    oxygen_device VARCHAR(50),
    oxygen_flow DECIMAL(5,2),
    mobility_score INT,
    nurse_alert TINYINT,
    FOREIGN KEY (admission_id) REFERENCES Admissions(admission_id)
);

-- ===================================================================
-- QUERY 1: List elderly patients (age > 70) with high comorbidity index
-- Concepts: SELECT, WHERE, ORDER BY, Comparison operators
-- ===================================================================
SELECT 
    patient_id,
    patient_name,
    age,
    gender,
    comorbidity_index
FROM patients
WHERE age > 70 AND comorbidity_index >= 5
ORDER BY comorbidity_index DESC, age DESC;


-- ===================================================================
-- QUERY 2: Average vital signs by ward (using INNER JOIN and GROUP BY)
-- Concepts: INNER JOIN, AVG(), GROUP BY, ROUND()
-- ===================================================================
SELECT 
    w.ward_type,
    COUNT(DISTINCT v.admission_id) AS patient_visits,
    ROUND(AVG(v.heart_rate), 2) AS avg_heart_rate,
    ROUND(AVG(v.respiratory_rate), 2) AS avg_resp_rate,
    ROUND(AVG(v.spo2_pct), 2) AS avg_spo2,
    ROUND(AVG(v.systolic_bp), 2) AS avg_systolic_bp
FROM vitals_readings v
INNER JOIN admissions a ON v.admission_id = a.admission_id
INNER JOIN ward w ON a.ward_id = w.ward_id
GROUP BY w.ward_type;


-- ===================================================================
-- QUERY 3: Patients with sepsis risk score above average (using subquery)
-- Concepts: Subquery, AVG(), comparison with subquery result
-- ===================================================================
SELECT DISTINCT
    p.patient_name,
    p.age,
    l.sepsis_risk_score,
    (SELECT ROUND(AVG(sepsis_risk_score), 4) FROM lab_readings) AS hospital_avg
FROM lab_readings l
INNER JOIN admissions a ON l.admission_id = a.admission_id
INNER JOIN patients p ON a.patient_id = p.patient_id
WHERE l.sepsis_risk_score > (SELECT AVG(sepsis_risk_score) FROM lab_readings)
ORDER BY l.sepsis_risk_score DESC
LIMIT 10;


-- ===================================================================
-- QUERY 4: Count of deterioration predictions by admission type
-- Concepts: COUNT(), GROUP BY, HAVING, CASE (implicit)
-- ===================================================================
SELECT 
    a.admission_type,
    COUNT(*) AS total_readings,
    SUM(l.deterioration_next_12h) AS deterioration_predictions,
    ROUND(AVG(l.sepsis_risk_score), 4) AS avg_sepsis_risk
FROM lab_readings l
INNER JOIN admissions a ON l.admission_id = a.admission_id
GROUP BY a.admission_type
HAVING COUNT(*) > 10;


-- ===================================================================
-- QUERY 5: Patients who had nurse alerts with their vital signs
-- Concepts: WHERE with condition, ORDER BY, Multiple columns
-- ===================================================================
SELECT 
    v.admission_id,
    v.hour_from_admission,
    v.heart_rate,
    v.respiratory_rate,
    v.spo2_pct,
    v.systolic_bp,
    v.nurse_alert
FROM vitals_readings v
WHERE v.nurse_alert = 1
ORDER BY v.admission_id, v.hour_from_admission;


-- ===================================================================
-- QUERY 6: Ward comparison with LEFT JOIN and aggregate functions
-- Concepts: LEFT JOIN, COUNT, AVG, MIN, MAX, GROUP BY
-- ===================================================================
SELECT 
    w.ward_id,
    w.ward_type,
    COUNT(a.admission_id) AS total_admissions,
    ROUND(AVG(a.los_hours), 2) AS avg_los_hours,
    MIN(a.los_hours) AS min_los_hours,
    MAX(a.los_hours) AS max_los_hours,
    SUM(a.deterioration_event) AS deterioration_events
FROM ward w
LEFT JOIN admissions a ON w.ward_id = a.ward_id
GROUP BY w.ward_id, w.ward_type;


-- ===================================================================
-- QUERY 7: Trend of sepsis risk over time (hour from admission)
-- Concepts: GROUP BY, AVG(), ORDER BY, Time-based analysis
-- ===================================================================
SELECT 
    hour_from_admission,
    COUNT(*) AS num_readings,
    ROUND(AVG(sepsis_risk_score), 4) AS avg_sepsis_risk,
    ROUND(MIN(sepsis_risk_score), 4) AS min_sepsis_risk,
    ROUND(MAX(sepsis_risk_score), 4) AS max_sepsis_risk
FROM lab_readings
GROUP BY hour_from_admission
ORDER BY hour_from_admission;


-- ===================================================================
-- QUERY 8: Patient risk categorization using CASE statement
-- Concepts: CASE WHEN, Multiple conditions, String concatenation concept
-- ===================================================================
SELECT
 patient_name,
 age,
 comorbidity_index,
 CASE
 WHEN age >= 75 AND comorbidity_index >= 6 THEN 'CRITICAL HIGH RISK'
 WHEN age >= 70 OR comorbidity_index >= 6 THEN 'HIGH RISK'
 WHEN age >= 60 OR comorbidity_index >= 4 THEN 'MODERATE RISK'
 WHEN age >= 50 OR comorbidity_index >= 2 THEN 'LOW MODERATE RISK'
 ELSE 'LOW RISK'
 END AS risk_category
FROM patients
ORDER BY
 CASE
 WHEN age >= 75 AND comorbidity_index >= 6 THEN 1
 WHEN age >= 70 OR comorbidity_index >= 6 THEN 2
 WHEN age >= 60 OR comorbidity_index >= 4 THEN 3
 WHEN age >= 50 OR comorbidity_index >= 2 THEN 4
 ELSE 5
 END,
 comorbidity_index DESC,
 age DESC;


-- ===================================================================
-- ===================================================================
-- QUERY 9: Compare patients with high vs low comorbidity using SELF JOIN
-- (Comparing patients within same age group)
-- Concepts: SELF JOIN, Alias, Table to itself comparison
-- ===================================================================
-- This query pairs patients who are in the same age range (±5 years)
-- to compare their comorbidity index and sepsis risk

SELECT
 p1.patient_name AS patient1_name,
 p1.age AS patient1_age,
 p1.comorbidity_index AS patient1_comorbidity,
 p2.patient_name AS patient2_name,
 p2.age AS patient2_age,
 p2.comorbidity_index AS patient2_comorbidity,
 ABS(p1.comorbidity_index - p2.comorbidity_index) AS comorbidity_difference
FROM patients p1
INNER JOIN patients p2
 ON p1.patient_id != p2.patient_id
 AND ABS(p1.age - p2.age) <= 5
 AND p1.comorbidity_index > p2.comorbidity_index
WHERE p1.comorbidity_index >= 6
 AND p2.comorbidity_index <= 3
ORDER BY comorbidity_difference DESC, p1.age DESC
LIMIT 15;

-- ===================================================================
-- QUERY 10: UPDATE and DELETE operations (DML) that work with your data
-- Concepts: UPDATE with JOIN, DELETE with WHERE, Verification queries
-- ===================================================================

-- 10a: UPDATE - Increase baseline risk score for patients in Ward-C (Emergency Room)
-- These patients have higher acuity and need adjusted risk scores

-- BEFORE UPDATE: view current data for Ward-C patients
SELECT
 a.admission_id,
 p.patient_name,
 p.age,
 w.ward_type,
a.baseline_risk_score AS current_risk_score
FROM admissions a
INNER JOIN patients p ON a.patient_id = p.patient_id
INNER JOIN ward w ON a.ward_id = w.ward_id
WHERE w.ward_id = 'W-C'
LIMIT 5;
-- PERFORM UPDATE
UPDATE admissions a
INNER JOIN ward w ON a.ward_id = w.ward_id
SET a.baseline_risk_score = ROUND(a.baseline_risk_score * 1.2, 4)
WHERE w.ward_id = 'W-C';
-- AFTER UPDATE: verify the changes
SELECT
 a.admission_id,
 p.patient_name,
 p.age,
 w.ward_type,
 a.baseline_risk_score AS updated_risk_score,
 ROUND(a.baseline_risk_score / 1.2, 4) AS original_risk_calculated
FROM admissions a
INNER JOIN patients p ON a.patient_id = p.patient_id
INNER JOIN ward w ON a.ward_id = w.ward_id
WHERE w.ward_id = 'W-C'
LIMIT 5;

-- 10b: DELETE - Remove duplicate or unnecessary data (simulated with SELECT)
-- Note: Since your data is clean, we'll show a safe DELETE example
-- and verify no data loss occurs

-- BEFORE DELETE: identify exactly which records will be removed
SELECT
 lab_id,
 admission_id,
 hour_from_admission,
 sepsis_risk_score,
 deterioration_next_12h
FROM lab_readings
WHERE sepsis_risk_score < 0.20
 AND hour_from_admission <= 3
AND deterioration_next_12h = 0;
-- PERFORM DELETE
DELETE FROM lab_readings
WHERE sepsis_risk_score < 0.20
 AND hour_from_admission <= 3
 AND deterioration_next_12h = 0;
-- AFTER DELETE: verify removal and updated stats
SELECT
 COUNT(*) AS remaining_readings,
 ROUND(MIN(sepsis_risk_score), 4) AS min_sepsis_risk,
 ROUND(AVG(sepsis_risk_score), 4) AS avg_sepsis_risk,
 ROUND(MAX(sepsis_risk_score), 4) AS max_sepsis_risk
FROM lab_readings;
