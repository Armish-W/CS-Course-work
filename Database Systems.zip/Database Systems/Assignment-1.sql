DROP DATABASE IF EXISTS RetailDB;
CREATE DATABASE RetailDB;
USE RetailDB;

-- 1. Create Suppliers table
CREATE TABLE Suppliers (
    supplier_id INT PRIMARY KEY NOT NULL,
    supplier_name VARCHAR(100) NOT NULL,
    contact_email VARCHAR(100) UNIQUE,
    city VARCHAR(50),
    phone_number VARCHAR(50),
    registration_date DATE NOT NULL DEFAULT (CURDATE())
);

-- 2. Create Customers Table
CREATE TABLE Customers (
    customer_id INT PRIMARY KEY NOT NULL,
    customer_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    city VARCHAR(50),
    gender CHAR(1) CHECK (gender IN ('M', 'F')),
    registration_date DATE NOT NULL DEFAULT (CURDATE())
);

-- 3. Create Products Table
CREATE TABLE Products (
    product_id INT PRIMARY KEY NOT NULL,
    product_name VARCHAR(50) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL CHECK(price >= 0),
    stock_quantity INT NOT NULL DEFAULT 0 CHECK(stock_quantity >= 0),
    is_active BOOLEAN DEFAULT TRUE,
    supplier_id INT,
    FOREIGN KEY (supplier_id) REFERENCES Suppliers(supplier_id)
);

-- 4. Create Sales Table
CREATE TABLE Sales (
    sale_id INT PRIMARY KEY NOT NULL,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL CHECK(quantity > 0),
    sale_date DATE NOT NULL DEFAULT (CURDATE()),
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- Inserting Data
-- 1.Suppliers 
INSERT INTO Suppliers (supplier_id, supplier_name, contact_email, city, phone_number, registration_date) VALUES
(1001, 'Xtech', 'sales@xtech.com', 'Dubai', '055-1234567', '2024-03-12'),
(1002, 'Educative', 'info@educative.com', 'LA', '842-0244', '2023-09-16'),
(1003, 'JenPharm', 'support@jenpharm.com', 'Tehran', '021-0311234', '2025-01-07'),
(1004, 'Global Garments', 'ops@globalg.com', 'Sharjah', '050-9988776', '2024-05-10'),
(1005, 'Fresh Foods', 'contact@freshf.com', 'Abu Dhabi', '052-5544332', '2023-11-20'),
(1006, 'Elite Electronics', 'elite@tech.com', 'Ajman', '056-1122334', '2024-01-15'),
(1007, 'Kitchen King', 'chef@kitchen.com', 'Dubai', '055-7766554', '2024-08-05'),
(1008, 'Sportify', 'info@sportify.com', 'Sharjah', '050-2233445', '2023-06-22'),
(1009, 'Organic Goods', 'support@organic.com', 'Dubai', '055-3344556', '2025-02-14'),
(1010, 'Book Haven', 'read@books.com', 'Abu Dhabi', '052-8877665', '2024-04-30'),
(1011, 'Beauty Best', 'care@beauty.com', 'Ajman', '056-9900112', '2023-12-01'),
(1012, 'Toys R Us', 'play@toys.com', 'Dubai', '055-6677889', '2024-07-19'),
(1013, 'Gadget Hub', 'hello@gadget.com', 'Abu Dhabi', '052-1122330', '2025-01-25'),
(1014, 'Office Mart', 'corp@office.com', 'Sharjah', '050-4455667', '2024-02-28'),
(1015, 'Auto Parts', 'fix@auto.com', 'Dubai', '055-8899001', '2023-10-11');

-- 2. Customers 
INSERT INTO Customers (customer_id, customer_name, email, city, gender, registration_date) VALUES
(1, 'Milly', 'Milly.zia@email.com', NULL, 'F', '2022-02-14'),
(2, 'Ashley', 'Ashley.kate@email.com', 'Los Angeles', 'F', '2025-03-12'),
(3, 'James', 'james.smith@email.com', 'Chicago', 'M', '2025-02-01'),
(4, 'Armish', 'Armish.wyne@email.com', 'Miami', 'F', '2026-03-12'),
(5, 'Miley', 'Miley.henry@email.com', 'Dubai' , 'F', '2025-04-18'),
(6, 'Chris Evans', 'chris@mail.com', 'Dubai', 'M', '2025-02-26'),
(7, 'Hina S', 'hina@mail.com', 'Ajman', 'F', '2025-02-27'),
(8, 'Bilal R', 'bilal@mail.com', 'Dubai', 'M', '2025-02-28'),
(9, 'Dina M', 'dina@mail.com', 'Sharjah', 'F', '2026-01-01'),
(10, 'Ryan G', 'ryan@mail.com', 'Abu Dhabi', 'M', '2026-01-05'),
(11, 'Nora F', 'nora@mail.com', 'Dubai', 'F', '2026-01-10'),
(12, 'Karam T', 'karam@mail.com', 'Ajman', 'M', '2026-02-01'),
(13, 'Sara Khan', 'sara@mail.com', 'Abu Dhabi', 'F', '2025-01-15'),
(14, 'Zaid Omar', 'zaid@mail.com', 'Ajman', 'M', '2025-02-12'),
(15, 'Fatima Noor', 'fatima@mail.com', 'Dubai', 'F', '2025-02-20');

-- 3.Products
INSERT INTO Products (product_id, product_name, category, price, stock_quantity, is_active, supplier_id) VALUES
(101, 'Oats', 'Grocery', 12.00, 50, 1, 1003),
(102, 'Headphones', 'Electronics', 150.00, 30, 1, 1001),
(103, 'Phone', 'Electronics', 1200.00, 15, 1, 1001),
(104, 'Jeans', 'Clothing', 25.50, 100, 1, 1002),
(105, 'Mouse', 'Electronics', 45.00, 25, 0, 1001),
(106, 'Tablet', 'Electronics', 950.00, 10, 1, 1001),
(107, 'Smart Watch', 'Electronics', 1100.00, 20, 1, 1006),
(108, 'Coffee Maker', 'Electronics', 1250.00, 5, 1, 1007),
(109, 'Milk 1L', 'Grocery', 5.50, 120, 1, 1005),
(110, 'Bread', 'Grocery', 3.00, 80, 1, 1005),
(111, 'Running Shoes', 'Clothing', 400.00, 18, 1, 1004),
(112, 'Yoga Mat', 'Sporting Goods', 150.00, 25, 1, 1008),
(113, 'Office Chair', 'Furniture', 600.00, 8, 1, 1014),
(114, 'Microwave', 'Electronics', 1150.00, 7, 1, 1007),
(115, 'Desk Lamp', 'Furniture', 105.00, 40, 1, 1014);

-- 4. Sales 
INSERT INTO Sales (sale_id, customer_id, product_id, quantity, sale_date) VALUES
(1001, 1, 105, 1, '2025-01-06'), -- Monday
(1002, 2, 102, 3, '2025-01-07'), -- Tuesday
(1003, 1, 103, 5, '2025-02-10'), -- Monday
(1004, 3, 105, 1, '2025-02-12'), -- Wednesday
(1005, 4, 112, 2, '2025-02-20'), -- Thursday
(1006, 5, 101, 1, '2025-03-01'), -- Saturday
(1007, 6, 107, 1, '2025-01-13'), -- Monday
(1008, 2, 101, 2, '2025-01-13'), -- Monday
(1010, 8, 115, 4, '2025-02-03'), -- Monday
(1012, 9, 103, 1, '2025-02-04'), -- Tuesday
(1014, 10, 114, 2, '2025-02-11'), -- Tuesday
(1016, 11, 111, 3, '2025-02-12'), -- Wednesday
(1018, 12, 110, 10, '2026-01-05'), -- Monday
(1020, 13, 113, 1, '2026-01-06'), -- Tuesday
(1022, 14, 106, 2, '2026-01-07'); -- Wednesday
-- Q1
SELECT DISTINCT city, gender FROM Customers ORDER BY city, gender;

-- Q2
SELECT product_name, price AS original_price, (price * 0.90) AS discounted_price 
FROM Products WHERE price > 1000 AND is_active = 1 
ORDER BY discounted_price DESC;

-- Q3
SELECT * FROM Sales 
WHERE quantity > 1 AND DAYNAME(sale_date) IN ('Monday', 'Tuesday', 'Wednesday') 
ORDER BY sale_date DESC, quantity ASC;

-- Q4
SELECT category, COUNT(*) AS total_products, SUM(stock_quantity) AS total_stock 
FROM Products GROUP BY category HAVING COUNT(*) > 2 
ORDER BY total_products DESC;

-- Q5
SELECT category, AVG(price) AS average_price, MAX(price) AS maximum_price 
FROM Products GROUP BY category HAVING average_price > 1000 
ORDER BY average_price DESC;

-- Q6
SELECT customer_id, SUM(quantity) AS total_quantity, COUNT(sale_id) AS order_count 
FROM Sales WHERE quantity > 0 
GROUP BY customer_id ORDER BY total_quantity DESC;

-- Q7
SELECT category, MIN(price) AS min_price, MAX(price) AS max_price, AVG(price) AS avg_price 
FROM Products GROUP BY category HAVING min_price < 5000 
ORDER BY avg_price DESC;

-- Q8
SELECT product_id, SUM(quantity) AS total_quantity, COUNT(DISTINCT customer_id) AS unique_customers 
FROM Sales GROUP BY product_id HAVING total_quantity > 2 
ORDER BY total_quantity DESC;

-- Q9
SELECT product_id, SUM(quantity) AS total_units, AVG(quantity) AS avg_qty 
FROM Sales GROUP BY product_id HAVING total_units > 1 
ORDER BY total_units DESC, avg_qty ASC;

-- Q10
SELECT * FROM Sales 
WHERE quantity > 1 AND (sale_date BETWEEN '2025-01-01' AND '2025-03-01') AND sale_id % 2 = 0 
ORDER BY sale_date DESC, quantity ASC;

-- Q11
SELECT category, SUM(stock_quantity) AS total_stock, COUNT(product_id) AS product_count 
FROM Products GROUP BY category HAVING total_stock > 20 
ORDER BY total_stock DESC;

-- Q12
SELECT 
    CONCAT(UPPER(LEFT(customer_name, 1)), LOWER(SUBSTRING(customer_name, 2))) AS formatted_name,
    DATE_FORMAT(registration_date, "%b-%Y") AS reg_date
FROM Customers WHERE registration_date < CURDATE() 
ORDER BY registration_date DESC;