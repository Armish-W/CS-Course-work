/*
 * Network Bandwidth Allocation
 * Analysis of Algorithms - Post-Midterm Assignment
 * Greedy + Dynamic Programming (0/1 Knapsack)
 */

#include <iostream>
#include <algorithm>
#include <iomanip>
using namespace std;


//  Service data

const int N = 6;   // number of services
const int M = 10;  // max bandwidth (Mbps)

string id[]  = {"S1","S2","S3","S4","S5","S6"};
int    bw[]  = { 0,  4,   1,   5,   3,   2,   3 }; // 1-indexed; bw[0] unused
int    pri[] = { 0,  8,   3,   9,   6,   4,   5 }; // 1-indexed; pri[0] unused


//  TASK A – Greedy Algorithm

int greedyTotalPriority = 0;
void greedySolution()
{
    cout << "==============================\n";
    cout << "  TASK A: GREEDY ALGORITHM\n";
    cout << "==============================\n\n";

    // Compute ratio and sort indices by ratio descending
    int idx[N];
    for (int i = 0; i < N; i++) idx[i] = i + 1; // 1-indexed services

    // Bubble sort by priority/bandwidth ratio (descending)
    for (int i = 0; i < N - 1; i++)
        for (int j = 0; j < N - i - 1; j++)
        {
            double r1 = (double)pri[idx[j]]   / bw[idx[j]];
            double r2 = (double)pri[idx[j+1]] / bw[idx[j+1]];
            if (r1 < r2) swap(idx[j], idx[j+1]);
        }

    cout << "Services sorted by Priority/Bandwidth ratio:\n\n";
    cout << left << setw(10) << "Service"
         << setw(15) << "Bandwidth"
         << setw(10) << "Priority"
         << "Ratio\n";
    cout << string(45, '-') << "\n";
    for (int i = 0; i < N; i++)
    {
        int k = idx[i];
        cout << left << setw(10) << id[k-1]
             << setw(15) << bw[k]
             << setw(10) << pri[k]
             << fixed << setprecision(2)
             << (double)pri[k]/bw[k] << "\n";
    }

    // Greedy selection
    int remaining = M;
    int totalBW  = 0;
	greedyTotalPriority = 0;
    bool selected[N+1] = {false};

    cout << "\nGreedy Selection Process:\n\n";
    for (int i = 0; i < N; i++)
    {
        int k = idx[i];
        if (bw[k] <= remaining)
        {
            selected[k] = true;
            remaining  -= bw[k];
            totalBW    += bw[k];
            greedyTotalPriority  += pri[k];
            cout << "  Selected " << id[k-1]
                 << " (BW=" << bw[k] << ", Pri=" << pri[k]
                 << ") -> Remaining BW=" << remaining << "\n";
        }
        else
        {
            cout << "  Skipped  " << id[k-1]
                 << " (BW=" << bw[k] << " > remaining " << remaining << ")\n";
        }
    }

    cout << "\nGreedy Result:\n\n";
    cout << "  Selected services: ";
    for (int i = 1; i <= N; i++) if (selected[i]) cout << id[i-1] << " ";
    cout << "\n  Total Bandwidth : " << totalBW  << " Mbps\n";
    cout << "  Total Priority  : " << greedyTotalPriority << "\n\n";
}


//  TASK B – Dynamic Programming (0/1 Knapsack)

int k[N+1][M+1]; // DP table
int dpTotalPriority = 0;

void dpSolution()
{
    cout << "==============================\n";
    cout << "  TASK B: DYNAMIC PROGRAMMING\n";
    cout << "==============================\n\n";

    // Fill DP table
    for (int i = 0; i <= N; i++)
    {
        for (int w = 0; w <= M; w++)
        {
            if (i == 0 || w == 0)
                k[i][w] = 0;
            else if (bw[i] <= w)
                k[i][w] = max(pri[i] + k[i-1][w - bw[i]], k[i-1][w]);
            else
                k[i][w] = k[i-1][w];
        }
    }

    // Print DP table
    cout << "DP Table k[i][w] (rows=services 0-6, cols=capacity 0-10):\n\n";
    cout << "     ";
    for (int w = 0; w <= M; w++) cout << setw(4) << w;
    cout << "\n     " << string(44, '-') << "\n";
    for (int i = 0; i <= N; i++)
    {
        cout << "i=" << i << " |";
        for (int w = 0; w <= M; w++) cout << setw(4) << k[i][w];
        cout << "\n";
    }

    // Backtrack using the exact logic discussed
    cout << "\nBacktracking to find selected services:\n\n";
    int i = N, j = M;
    bool selected[N+1] = {false};

    while (i > 0 && j > 0)
    {
        if (k[i][j] == k[i-1][j])
        {
            cout << "  " << id[i-1] << " = 0 (not selected)\n";
            i--;
        }
        else
        {
            cout << "  " << id[i-1] << " = 1 (SELECTED)\n";
            selected[i] = true;
            j = j - bw[i]; // subtract weight FIRST (correct order)
            i--;            // then decrement i
        }
    }

    int totalBW = 0;
	dpTotalPriority = 0;
    for (int x = 1; x <= N; x++)
        if (selected[x]) { totalBW += bw[x]; dpTotalPriority += pri[x]; }

    cout << "\nDP Result:\n\n";
    cout << "  Selected services: ";
    for (int x = 1; x <= N; x++) if (selected[x]) cout << id[x-1] << " ";
    cout << "\n  Total Bandwidth : " << totalBW  << " Mbps\n";
    cout << "  Total Priority  : " << dpTotalPriority << "\n\n";
}


//  Main function

int main()
{
    cout << "\n==============================================\n";
    cout << "  Network Bandwidth Allocation\n";
    cout << "  Max Bandwidth: " << M << " Mbps | Services: " << N << "\n";
    cout << "==============================================\n\n";

    greedySolution();
    dpSolution();

    cout << "==============================\n";
    cout << "  TASK C: COMPARISON\n";
    cout << "==============================\n\n";
    cout << "  Greedy Total Priority: " << greedyTotalPriority << "\n";
    cout << "  DP     Total Priority: " << dpTotalPriority << " (OPTIMAL)\n";
    cout << "  Greedy may produce suboptimal results\n";
    cout << "  because the ratio heuristic does not account\n";
    cout << "  for the 0/1 constraint (no partial selection).\n\n";

    return 0;
}
