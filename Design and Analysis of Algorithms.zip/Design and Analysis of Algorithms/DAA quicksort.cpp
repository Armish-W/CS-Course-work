// algo quicksort.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

// Partition - First Element Pivot
int partitionFirst(int A[], int low, int high)
{
    int pivot = A[low];
    int i = low + 1;
    for (int j = low + 1; j <= high; j++)
    {
        if (A[j] <= pivot)
        {
            int temp = A[i];
            A[i] = A[j];
            A[j] = temp;
            i++;
        }
    }
    int temp = A[low];
    A[low] = A[i - 1];
    A[i - 1] = temp;
    return i - 1;
}

// Partition - Randomized Pivot
int partitionRandom(int A[], int low, int high)
{
    int pivotIndex = low + rand() % (high - low + 1);
    int temp = A[low];
    A[low] = A[pivotIndex];
    A[pivotIndex] = temp;
    return partitionFirst(A, low, high);
}

// Quick Sort - First Element Pivot (Recursive)
void quickSortFirst(int A[], int low, int high)
{
    if (low < high)
    {
        int pi = partitionFirst(A, low, high);
        quickSortFirst(A, low, pi - 1);
        quickSortFirst(A, pi + 1, high);
    }
}

// Quick Sort - Randomized Pivot (Recursive)
void quickSortRandom(int A[], int low, int high)
{
    if (low < high)
    {
        int pi = partitionRandom(A, low, high);
        quickSortRandom(A, low, pi - 1);
        quickSortRandom(A, pi + 1, high);
    }
}

int main()
{
    int A[10000];
    char cont = 'y';
    srand(time(0));

    while (cont == 'y' || cont == 'Y')
    {
        int n, choice, strategy;

        cout << "\nEnter number of elements (max 10000): ";
        cin >> n;

        cout << "Select input type:\n";
        cout << "1. Random\n2. Sorted\n3. Reverse Sorted\n";
        cin >> choice;

        cout << "Select pivot strategy:\n";
        cout << "1. First Element Pivot\n2. Randomized Pivot\n";
        cin >> strategy;

        if (choice == 1)
        {
            for (int i = 0; i < n; i++)
                A[i] = rand() % 10000;
        }
        else if (choice == 2)
        {
            for (int i = 0; i < n; i++)
                A[i] = i;
        }
        else if (choice == 3)
        {
            for (int i = 0; i < n; i++)
                A[i] = n - i;
        }
        else
        {
            cout << "Invalid choice!";
            continue;
        }

        int repeat = 100;
        clock_t start = clock();

        for (int k = 0; k < repeat; k++)
        {
            int temp[10000];
            for (int i = 0; i < n; i++)
                temp[i] = A[i];

            if (strategy == 1)
                quickSortFirst(temp, 0, n - 1);
            else if (strategy == 2)
                quickSortRandom(temp, 0, n - 1);
            else
            {
                cout << "Invalid strategy!";
                continue;
            }
        }

        clock_t end = clock();
        double time_taken = double(end - start) / CLOCKS_PER_SEC;

        cout << "\nTime taken for sorting " << n << " elements (repeated " << repeat << " times): "
            << time_taken << " seconds\n";

        cout << "\nDo you want to continue? (y/n): ";
        cin >> cont;
    }

    cout << "\nProgram ended.\n";
    return 0;
}