#include <iostream>
#include <string>
using namespace std;

/* -------------------------------------------------
   LEVEL EASY
------------------------------------------------- */
void contains10010() {
    string s;
    cout << "Enter binary string: ";
    cin >> s;

    int state = 0;

    for (char c : s) {
        if (state == 0 && c == '1') state = 1;
        else if (state == 1 && c == '0') state = 2;
        else if (state == 2 && c == '0') state = 3;
        else if (state == 3 && c == '1') state = 4;
        else if (state == 4 && c == '0') state = 5;
        else if (c == '1') state = 1;
        else state = 0;
    }
    
    

    if (state == 5)
        cout << "Accepted\n";
    else
        cout << "Rejected\n";
}

/* -------------------------------------------------
   LEVEL MEDIUM
------------------------------------------------- */
void evenLength() {
    string s;
    cout << "Enter binary string: ";
    cin >> s;

    int state = 0;  // 0 = even, 1 = odd

    for (char c : s) {
        state = 1 - state; // toggle
    }

    if (state == 0)
        cout << "Accepted\n";
    else
        cout << "Rejected\n";
}

/* -------------------------------------------------
   LEVEL HARD
------------------------------------------------- */
void divisibleBy6() {
    string s;
    cout << "Enter binary string: ";
    cin >> s;

    int state = 0; // remainder mod 6

    for (char c : s) {
        if (c == '0')
            state = (state * 2) % 6;
        else if (c == '1')
            state = (state * 2 + 1) % 6;
        else {
            cout << "Invalid input\n";
            return;
        }
    }

    if (state == 0)
        cout << "Accepted\n";
    else
        cout << "Rejected\n";
}

/* -------------------------------------------------
   MAIN MENU
------------------------------------------------- */
int main() {
    int choice;

    cout << "Choose DFA Implementation Level\n";
    cout << "1. Easy\n";
    cout << "2. Medium\n";
    cout << "3. Hard\n";
    cout << "Enter choice: ";
    cin >> choice;

    switch (choice) {
    case 1:
        contains10010();
        break;
    case 2:
        evenLength();
        break;
    case 3:
        divisibleBy6();
        break;
    default:
        cout << "Invalid choice\n";
    }

    return 0;
}
