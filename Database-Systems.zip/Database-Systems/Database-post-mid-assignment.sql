CREATE DATABASE IF NOT EXISTS FinanceLab;
USE FinanceLab;
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE Transactions;
TRUNCATE TABLE Accounts; 
TRUNCATE TABLE Customers;
SET FOREIGN_KEY_CHECKS = 1;

-- CUSTOMERS: 21 unique customers
INSERT INTO Customers VALUES
(1,'Ali Khan','Lahore','Retail','2023-01-10'),        -- NORMAL: 6 txns but balance < avg
(2,'Sara Ahmed','Karachi','Corporate','2023-02-15'),  -- NORMAL
(3,'Bilal Sheikh','Islamabad','Retail','2023-03-01'), -- SILENT LOW-VALUE
(4,'Ayesha Malik','Lahore','SME','2023-04-12'),       -- NORMAL
(5,'Hassan Raza','Karachi','Retail','2023-05-18'),    -- SILENT LOW-VALUE  
(6,'Fatima Noor','Islamabad','Corporate','2023-06-20'),-- HIGH-VALUE ACTIVE
(7,'Usman Tariq','Lahore','SME','2023-07-05'),        -- SILENT LOW-VALUE
(8,'Zainab Ali','Karachi','Retail','2023-08-11'),     -- NORMAL
(9,'Omar Farooq','Islamabad','Corporate','2023-09-22'),-- SILENT HIGH-VALUE
(10,'Mariam Saeed','Lahore','Retail','2023-10-30'),   -- NORMAL
(11,'Ahmad Javed','Karachi','SME','2023-11-12'),      -- IRREGULAR - DRAINING
(12,'Hira Shah','Islamabad','Retail','2023-12-01'),   -- UNDERUTILISED + PEER
(13,'Imran Iqbal','Lahore','Corporate','2024-01-15'), -- SILENT HIGH-VALUE
(14,'Sana Tariq','Karachi','Retail','2024-02-20'),    -- NORMAL
(15,'Tariq Mehmood','Islamabad','SME','2024-03-10'),  -- NORMAL
(16,'Nadia Khan','Lahore','Retail','2024-04-05'),     -- SILENT HIGH-VALUE
(17,'Hamza Ali','Karachi','Corporate','2024-05-12'),  -- SILENT HIGH-VALUE
(18,'Kiran Malik','Islamabad','Retail','2024-06-01'), -- UNDERUTILISED + PEER
(19,'Adnan Shah','Lahore','SME','2024-07-09'),        -- SIMILAR STRANGERS 
(20,'Mehak Raza','Lahore','SME','2024-08-25'),        -- SIMILAR STRANGERS
(21,'Zara','Peshawar','Retail','2024-09-01');         -- UNBANKED for CS2

-- ACCOUNTS: 20 accounts, bank_avg = 131,500
INSERT INTO Accounts VALUES
(101,1,'Savings',50000,5.5,'2023-01-15'),      -- NORMAL: 6 txns, balance < avg
(102,2,'Current',120000,0,'2023-02-20'),       -- NORMAL
(103,3,'Investment',40000,8.5,'2023-03-05'),  -- SILENT LOW-VALUE, 0 txns
(104,4,'Savings',75000,5.5,'2023-04-18'),      -- NORMAL
(105,5,'Savings',60000,5.5,'2023-05-25'),      -- SILENT LOW-VALUE, 0 txns
(106,6,'Investment',300000,9.0,'2023-06-25'),  -- HIGH-VALUE ACTIVE, 6 txns
(107,7,'Current',90000,0,'2023-07-12'),        -- SILENT LOW-VALUE, 0 txns
(108,8,'Savings',45000,5.5,'2023-08-15'),      -- NORMAL
(109,9,'Investment',400000,8.0,'2023-09-30'),  -- SILENT HIGH-VALUE, 0 txns
(110,10,'Savings',55000,5.5,'2023-10-31'),     -- NORMAL
(111,11,'Current',110000,0,'2023-11-20'),      -- IRREGULAR - DRAINING
(112,12,'Savings',65000,5.5,'2023-12-10'),     -- UNDERUTILISED + PEER to 118
(113,13,'Investment',250000,8.5,'2024-01-20'), -- SILENT HIGH-VALUE, 0 txns
(114,14,'Savings',70000,5.5,'2024-02-25'),     -- NORMAL
(115,15,'Current',130000,0,'2024-03-15'),      -- NORMAL
(116,16,'Savings',160000,5.5,'2024-04-12'),    -- SILENT HIGH-VALUE, 0 txns
(117,17,'Investment',350000,9.2,'2024-05-20'), -- SILENT HIGH-VALUE, 0 txns
(118,18,'Current',95000,0,'2024-06-05'),       -- UNDERUTILISED, 2 txns + PEER to 112
(119,19,'Savings',80000,5.5,'2024-07-15'),     -- SIMILAR STRANGERS, 3 txns + PEER to 120
(120,20,'Savings',85000,5.5,'2024-08-25');     -- SIMILAR STRANGERS, 3 txns + PEER to 119

-- TRANSACTIONS: Designed to trigger each flag
INSERT INTO Transactions VALUES
-- Ali Khan acct 101: 6 txns but balance < avg → NORMAL
(1001,101,'Deposit',10000,'2024-01-05'),
(1002,101,'Withdrawal',5000,'2024-02-10'),
(1003,101,'Deposit',25000,'2024-03-15'),
(1004,101,'Deposit',12000,'2024-04-01'),
(1005,101,'Withdrawal',8000,'2024-04-10'),
(1006,101,'Deposit',50000,'2024-05-05'),
-- Fatima Noor acct 106: 6 txns + 300k balance → HIGH-VALUE ACTIVE 
(1007,106,'Deposit',7000,'2024-05-12'),
(1008,106,'Withdrawal',20000,'2024-06-02'),
(1009,106,'Deposit',9000,'2024-06-20'),
(1010,106,'Deposit',15000,'2024-07-01'),
(1011,106,'Withdrawal',30000,'2024-07-10'),
(1012,106,'Deposit',11000,'2024-07-18'),
-- Ahmad Javed acct 111: DRAINING → 5k deposit vs 100k withdrawals
(1013,111,'Deposit',5000,'2024-08-05'),
(1014,111,'Withdrawal',80000,'2024-09-10'),
(1015,111,'Withdrawal',20000,'2024-10-01'),
-- Hira Shah acct 112: UNDERUTILISED → exactly 2 txns, balance 65k
(1016,112,'Deposit',5000,'2024-08-15'),
(1017,112,'Withdrawal',2000,'2024-08-22'),
-- Kiran Malik acct 118: UNDERUTILISED → exactly 2 txns, balance 95k  
-- PEER to 112: Islamabad, Retail, |95k-65k|=30k<50k, both txn_count=2
(1018,118,'Deposit',5000,'2024-09-01'),
(1019,118,'Withdrawal',1000,'2024-09-10'),
-- Adnan Shah acct 119: SIMILAR STRANGERS → 3 txns, Lahore SME, 80k
(1020,119,'Deposit',5000,'2024-09-01'),
(1021,119,'Deposit',5000,'2024-09-02'),
(1022,119,'Deposit',5000,'2024-09-03'),
-- Mehak Raza acct 120: SIMILAR STRANGERS → 3 txns, Lahore SME, 85k
-- PEER to 119: Lahore, SME, |85k-80k|=5k<50k, both txn_count=3
(1023,120,'Deposit',5000,'2024-09-04'),
(1024,120,'Deposit',5000,'2024-09-05'),
(1025,120,'Deposit',5000,'2024-09-06'),
-- Normal activity for others
(1026,102,'Deposit',10000,'2024-01-01'),
(1027,104,'Deposit',8000,'2024-01-02'),
(1028,108,'Deposit',9000,'2024-01-03'),
(1029,110,'Deposit',7000,'2024-01-04'),
(1030,114,'Deposit',6000,'2024-01-05'),
(1031,115,'Deposit',12000,'2024-01-06');
 
WITH
 
-- ── LAYER 1: Transaction summary per account ──────────────────
-- LEFT JOIN keeps accounts with zero transactions visible
account_activity AS (
    SELECT
        a.account_id,
        a.customer_id,
        a.account_type,
        a.opening_balance,
        COUNT(t.transaction_id)                                  AS txn_count,
        IFNULL(SUM(CASE WHEN t.transaction_type = 'Deposit'
                        THEN t.amount ELSE 0 END), 0)           AS total_deposits,
        IFNULL(SUM(CASE WHEN t.transaction_type = 'Withdrawal'
                        THEN t.amount ELSE 0 END), 0)           AS total_withdrawals,
        MAX(t.transaction_date)                                  AS last_txn_date
    FROM   Accounts a
    LEFT JOIN Transactions t ON a.account_id = t.account_id
    GROUP BY a.account_id, a.customer_id, a.account_type, a.opening_balance
),
 
-- ── LAYER 2: Attach customer info ─────────────────────────────
-- RIGHT JOIN ensures every account appears even if customer link is broken
customer_account AS (
    SELECT
        c.customer_name,
        c.city,
        c.segment,
        aa.*
    FROM   Customers c
    RIGHT JOIN account_activity aa ON c.customer_id = aa.customer_id
),
 
-- ── LAYER 3: Peer detection via SELF JOIN ─────────────────────
-- Finds accounts with matching city, segment, similar balance, same txn count
peer_matches AS (
    SELECT
        ca1.account_id                                           AS acct_id,
        COUNT(ca2.account_id)                                    AS similar_peer_count,
        GROUP_CONCAT(ca2.customer_name SEPARATOR ', ')           AS peer_names
    FROM   customer_account ca1
    INNER JOIN customer_account ca2
           ON  ca1.city          =  ca2.city
          AND  ca1.segment       =  ca2.segment
          AND  ca1.account_id   <>  ca2.account_id
          AND  ABS(ca1.opening_balance
                 - ca2.opening_balance) < 50000
          AND  ca1.txn_count     =  ca2.txn_count
    GROUP BY ca1.account_id
),
 
-- ── LAYER 4: Bank-wide benchmark ─────────────────────────────
-- Single average balance used as dynamic 'high-value' threshold
bank_avg AS (
    SELECT AVG(opening_balance) AS avg_bal
    FROM   Accounts
)
 
-- ── FINAL SELECT: Combine all layers, assign Account_Flag ─────
SELECT
    ca.account_id,
    ca.customer_name,
    ca.city,
    ca.segment,
    ca.account_type,
    ca.opening_balance,
    ROUND(ba.avg_bal, 2)                                         AS bank_avg_balance,
    ca.txn_count,
    ca.total_deposits,
    ca.total_withdrawals,
    ca.last_txn_date,
    DATEDIFF(CURDATE(), ca.last_txn_date)                        AS days_since_last_txn,
    IFNULL(pm.peer_names, 'None')                                AS peer_accounts,
 
    -- ── MANDATORY FIELD: Account_Flag ───────────────────────
    CASE
        -- Priority 1: Large balance, no activity at all
        WHEN ca.opening_balance > ba.avg_bal
             AND ca.txn_count = 0
             THEN 'SILENT HIGH-VALUE'
 
        -- Priority 2: Small balance, no activity
        WHEN ca.opening_balance <= ba.avg_bal
             AND ca.txn_count = 0
             THEN 'SILENT LOW-VALUE'
 
        -- Priority 3: Barely any activity
        WHEN ca.txn_count BETWEEN 1 AND 2
             THEN 'UNDERUTILISED'
 
        -- Priority 4: Draining — withdrawals exceed deposits by 50%
        WHEN ca.total_withdrawals > ca.total_deposits * 1.5
             AND ca.txn_count > 0
             THEN 'IRREGULAR - DRAINING'
 
        -- Priority 5: High balance AND active — expected, healthy
        WHEN ca.opening_balance > ba.avg_bal
             AND ca.txn_count > 5
             THEN 'HIGH-VALUE ACTIVE'
 
        -- Priority 6: Suspicious similarity to other accounts
        WHEN pm.similar_peer_count >= 1
             THEN 'SIMILAR STRANGERS DETECTED'
 
        -- Default
        ELSE 'NORMAL'
    END                                                          AS Account_Flag
 
FROM   customer_account ca
CROSS JOIN bank_avg ba
LEFT JOIN peer_matches pm ON ca.account_id = pm.acct_id
 
ORDER BY
    FIELD(Account_Flag,
          'SILENT HIGH-VALUE',
          'IRREGULAR - DRAINING',
          'UNDERUTILISED',
          'SILENT LOW-VALUE',
          'SIMILAR STRANGERS DETECTED',
          'HIGH-VALUE ACTIVE',
          'NORMAL'),
    ca.opening_balance DESC;
    -- ----------------------------------
    -- Customer with NO account (for LEFT JOIN demonstration)
-- ID 22 used because 21 = Zara already exists from CS1
INSERT INTO Customers (customer_id, customer_name, city, segment, registration_date) VALUES
(22, 'Aamir Sohail', 'Multan', 'Retail', '2024-10-01');  -- UNBANKED

-- Second account for Adnan Shah (id 19 from CS1) to test multi-account logic
INSERT INTO Accounts (account_id, customer_id, account_type, opening_balance, interest_rate, open_date) VALUES
(121, 19, 'Current', 48000.00, 0, '2024-07-20');
    
    
    -- High activity for account 101 (Ali Khan) to create a POWER USER: 6 + 4 = 10 txns
INSERT INTO Transactions (transaction_id, account_id, transaction_type, amount, transaction_date) VALUES
(2021, 101, 'Deposit',    8000.00, '2026-01-05'),
(2022, 101, 'Withdrawal', 3000.00, '2026-01-20'),
(2023, 101, 'Deposit',   12000.00, '2026-02-10'),
(2024, 101, 'Deposit',    5000.00, '2026-03-01'),

-- Give Adnan Shah acct 121 one txn → OCCASIONAL
(2025, 121, 'Deposit',    9000.00, '2026-02-20');

    -- ============================================================
-- CASE STUDY 2: Hidden Customer Behaviour Network — Single Query
-- ============================================================

WITH
-- Step 1: Full customer picture — LEFT JOIN keeps customers without accounts
customer_summary AS (
    SELECT
        c.customer_id,
        c.customer_name,
        c.city,
        c.segment,
        c.registration_date,
        DATEDIFF(CURDATE(), c.registration_date)                        AS days_as_customer,
        COUNT(DISTINCT a.account_id)                                    AS account_count,
        IFNULL(SUM(a.opening_balance), 0)                              AS total_balance,
        COUNT(t.transaction_id)                                         AS txn_count,
        IFNULL(SUM(CASE WHEN t.transaction_type = 'Deposit'
                        THEN t.amount ELSE 0 END), 0)                  AS total_deposits,
        IFNULL(SUM(CASE WHEN t.transaction_type = 'Withdrawal'
                        THEN t.amount ELSE 0 END), 0)                  AS total_withdrawals,
        MAX(t.transaction_date)                                         AS last_txn_date
    FROM Customers c
    LEFT JOIN Accounts     a ON c.customer_id = a.customer_id   -- includes customers with no accounts
    LEFT JOIN Transactions t ON a.account_id  = t.account_id   -- includes accounts with no transactions
    GROUP BY c.customer_id, c.customer_name, c.city, c.segment, c.registration_date
),

-- Step 2: INNER JOIN to get only customers who DO have accounts (for segment stats)
segment_avg AS (
    SELECT
        c.segment,
        AVG(a.opening_balance)  AS seg_avg_balance,
        COUNT(DISTINCT c.customer_id) AS seg_customer_count
    FROM Customers c
    INNER JOIN Accounts a ON c.customer_id = a.customer_id
    GROUP BY c.segment
),

-- Step 3: SELF JOIN across ALL customers — find behaviour twins
--         (different city or segment, similar txn_count AND similar balance)
behaviour_twins AS (
    SELECT
        cs1.customer_id                                                  AS cust_id,
        GROUP_CONCAT(DISTINCT cs2.customer_name ORDER BY cs2.customer_name
                     SEPARATOR ', ')                                     AS twin_customers
    FROM customer_summary cs1
    INNER JOIN customer_summary cs2
        ON  cs1.customer_id <> cs2.customer_id
        AND (cs1.city <> cs2.city OR cs1.segment <> cs2.segment)        -- different city OR segment
        AND ABS(cs1.txn_count    - cs2.txn_count)    <= 1               -- similar activity level
        AND ABS(cs1.total_balance - cs2.total_balance) <= 30000         -- similar balance
    GROUP BY cs1.customer_id
),

-- Step 4: RIGHT JOIN to ensure every segment appears in stats table
--         (even segments with no active customers show up)
segment_report AS (
    SELECT
        cs.customer_id,
        sa.seg_avg_balance,
        sa.seg_customer_count
    FROM segment_avg sa
    RIGHT JOIN customer_summary cs ON sa.segment = cs.segment
)

-- ── FINAL SELECT ───────────────────────────────────────────
SELECT
    cs.customer_id,
    cs.customer_name,
    cs.city,
    cs.segment,
    cs.registration_date,
    cs.days_as_customer,
    cs.account_count,
    cs.total_balance,
    cs.txn_count,
    cs.total_deposits,
    cs.total_withdrawals,
    cs.last_txn_date,
    DATEDIFF(CURDATE(), cs.last_txn_date)                               AS days_inactive,
    ROUND(sr.seg_avg_balance, 2)                                        AS segment_avg_balance,
    bt.twin_customers,

    -- ── Mandatory Calculated Field: Customer Behaviour ──────
    CASE
        WHEN cs.account_count = 0
             THEN 'UNBANKED - NO ACCOUNT'
        WHEN cs.txn_count = 0
             THEN 'ACCOUNT HOLDER - NEVER TRANSACTED'
        WHEN cs.txn_count BETWEEN 1 AND 3
             AND cs.total_balance < (SELECT AVG(opening_balance) FROM Accounts)
             THEN 'OCCASIONAL - LOW VALUE'
        WHEN cs.txn_count BETWEEN 1 AND 3
             THEN 'OCCASIONAL - MODERATE'
        WHEN cs.txn_count BETWEEN 4 AND 6
             THEN 'REGULAR USER'
        WHEN cs.txn_count >= 7
             THEN 'POWER USER'
        WHEN cs.total_withdrawals > cs.total_deposits
             THEN 'AT RISK - NET OUTFLOW'
        ELSE 'STANDARD'
    END                                                                  AS Customer_Behaviour,

    -- Extra: vs segment average
    CASE
        WHEN cs.total_balance > IFNULL(sr.seg_avg_balance, 0)
             THEN 'ABOVE SEGMENT AVG'
        WHEN cs.total_balance = 0
             THEN 'NO BALANCE'
        ELSE 'BELOW SEGMENT AVG'
    END                                                                  AS balance_vs_segment,

    -- Extra: behaviour twin signal
    CASE WHEN bt.twin_customers IS NOT NULL THEN 'YES' ELSE 'NO'
    END                                                                  AS has_behaviour_twin

FROM customer_summary cs
LEFT JOIN segment_report sr ON cs.customer_id = sr.customer_id
LEFT JOIN behaviour_twins bt ON cs.customer_id = bt.cust_id
ORDER BY
    FIELD(Customer_Behaviour,
          'POWER USER','REGULAR USER','OCCASIONAL - MODERATE',
          'OCCASIONAL - LOW VALUE','AT RISK - NET OUTFLOW',
          'ACCOUNT HOLDER - NEVER TRANSACTED','UNBANKED - NO ACCOUNT','STANDARD'),
    cs.total_balance DESC;