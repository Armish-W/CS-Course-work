#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>
using namespace std;

// Enum for comparing Flight IDs
enum RelationType { LESS, GREATER, EQUAL };

// ----------------------- Flight Class -----------------------
class Flight
{
public:
    int flightID;             // Key (BST uses this)
    string destination;       // Destination city
    string departureTime;     // HH:MM format
    float flightDuration;     // Duration in hours
    string status;            // Departed, Landed, Delayed

    Flight()
    {
        flightID = 0;
        destination = "";
        departureTime = "";
        flightDuration = 0.0;
        status = "";
    }

    // Set flight data
    void SetFlight(int id, string dest, string dep, float duration, string stat)
    {
        flightID = id;
        destination = dest;
        departureTime = dep;
        flightDuration = duration;
        status = stat;
    }

    // Display flight data
    void ShowFlight() const
    {
        cout << "--------------------------------------" << endl;
        cout << "Flight ID: " << flightID << endl;
        cout << "Destination: " << destination << endl;
        cout << "Departure Time: " << departureTime << endl;
        cout << "Duration (hrs): " << flightDuration << endl;
        cout << "Status: " << status << endl;
        cout << "--------------------------------------" << endl;
    }

    // Compare flight IDs for BST ordering
    RelationType ComparedTo(const Flight& other) const
    {
        if (flightID < other.flightID)
            return LESS;
        else if (flightID > other.flightID)
            return GREATER;
        else
            return EQUAL;
    }

    // ETA formula as in document: ETA = Departure Time + Flight Duration
    string CalculateETA() const
    {
        // Extract hours and minutes from departure time
        int depHour = stoi(departureTime.substr(0, 2));
        int depMin = stoi(departureTime.substr(3, 2));

        // Convert departure time to decimal hours (e.g., 14:30 → 14.5)
        float depDecimal = depHour + depMin / 60.0;

        // Apply ETA formula from document
        float etaDecimal = depDecimal + flightDuration;

        // Wrap around 24-hour format if needed
        if (etaDecimal >= 24)
            etaDecimal -= 24;

        // Convert ETA back to HH:MM
        int etaHour = int(etaDecimal);
        int etaMin = int(round((etaDecimal - etaHour) * 60));

        if (etaMin == 60)  // adjust for rounding up to next hour
        {
            etaMin = 0;
            etaHour = (etaHour + 1) % 24;
        }

        // Format HH:MM with leading zeros
        string h = (etaHour < 10 ? "0" : "") + to_string(etaHour);
        string m = (etaMin < 10 ? "0" : "") + to_string(etaMin);
        return h + ":" + m;
    }

    // Determine punctuality based on status
    string PunctualityStatus() const
    {
        if (status == "Departed")
            return "En Route";
        else if (status == "Landed")
            return "On-Time";
        else if (status == "Delayed")
            return "Delayed";
        else
            return "Unknown";
    }
};

// ----------------------- Node Class -----------------------
class Node
{
public:
    Node* parent;
    Node* left;
    Node* right;
    Flight key;

    Node(Flight k)
    {
        parent = NULL;
        left = NULL;
        right = NULL;
        key = k;
    }
};

// ----------------------- BST Class -----------------------
class BST
{
private:
    Node* root;

    // Inorder traversal for sorted display
    void InOrder(Node* x)
    {
        if (x != NULL)
        {
            InOrder(x->left);
            x->key.ShowFlight();
            InOrder(x->right);
        }
    }

    // Helper: show flights by destination
    void DisplayByDestination(Node* x, const string& dest)
    {
        if (x != NULL)
        {
            DisplayByDestination(x->left, dest);
            if (x->key.destination == dest)
                x->key.ShowFlight();
            DisplayByDestination(x->right, dest);
        }
    }

    // Helper: show flights by status
    void DisplayByStatus(Node* x, const string& stat)
    {
        if (x != NULL)
        {
            DisplayByStatus(x->left, stat);
            if (x->key.status == stat)
                x->key.ShowFlight();
            DisplayByStatus(x->right, stat);
        }
    }

    // Helper: display ETA & punctuality
    void DisplayETA(Node* r)
    {
        if (r != NULL)
        {
            DisplayETA(r->left);
            cout << "Flight ID: " << r->key.flightID << endl;
            cout << "Destination: " << r->key.destination << endl;
            cout << "Departure: " << r->key.departureTime << endl;
            cout << "ETA: " << r->key.CalculateETA() << endl;
            cout << "Punctuality: " << r->key.PunctualityStatus() << endl;
            cout << "--------------------------------------" << endl;
            DisplayETA(r->right);
        }
    }

    // Helper: Surprise Feature — show flights by duration range
    void ShowByDurationRange(Node* x, float minDur, float maxDur)
    {
        if (x != NULL)
        {
            ShowByDurationRange(x->left, minDur, maxDur);
            if (x->key.flightDuration >= minDur && x->key.flightDuration <= maxDur)
                x->key.ShowFlight();
            ShowByDurationRange(x->right, minDur, maxDur);
        }
    }

    // Find minimum node
    Node* Minimum(Node* x)
    {
        while (x->left != NULL)
            x = x->left;
        return x;
    }

    // Replace subtrees for deletion
    void Transplant(Node* u, Node* v)
    {
        if (u->parent == NULL)
            root = v;
        else if (u == u->parent->left)
            u->parent->left = v;
        else
            u->parent->right = v;

        if (v != NULL)
            v->parent = u->parent;
    }

public:
    BST()
    {
        root = NULL;
    }

    Node* getRoot()
    {
        return root;
    }

    // Insert new node
    void Insert(Node* x)
    {
        Node* y = NULL;
        Node* z = root;

        while (z != NULL)
        {
            y = z;
            if (x->key.ComparedTo(z->key) == LESS)
                z = z->left;
            else
                z = z->right;
        }

        x->parent = y;
        if (y == NULL)
            root = x;
        else if (x->key.ComparedTo(y->key) == LESS)
            y->left = x;
        else
            y->right = x;
    }

    // Search for a node
    Node* Search(Node* x, int id)
    {
        if (x == NULL || x->key.flightID == id)
            return x;
        if (id < x->key.flightID)
            return Search(x->left, id);
        else
            return Search(x->right, id);
    }

    // Delete a node
    void Delete(Node* x)
    {
        if (x->left == NULL)
            Transplant(x, x->right);
        else if (x->right == NULL)
            Transplant(x, x->left);
        else
        {
            Node* y = Minimum(x->right);
            if (y->parent != x)
            {
                Transplant(y, y->right);
                y->right = x->right;
                if (y->right != NULL)
                    y->right->parent = y;
            }
            Transplant(x, y);
            y->left = x->left;
            if (y->left != NULL)
                y->left->parent = y;
        }
    }

    // Display all flights (sorted by Flight ID)
    void DisplayAll()
    {
        if (root == NULL)
            cout << "No flights to display.\n";
        else
            InOrder(root);
    }

    // Grouped by destination
    void ShowByDestination(string dest)
    {
        cout << "\nFlights to " << dest << ":\n";
        DisplayByDestination(root, dest);
    }

    // Grouped by status
    void ShowByStatus(string stat)
    {
        cout << "\nFlights with status: " << stat << "\n";
        DisplayByStatus(root, stat);
    }

    // ETA display
    void ShowETA()
    {
        if (root == NULL)
            cout << "No flights available.\n";
        else
            DisplayETA(root);
    }

    // Surprise feature: duration range
    void ShowFlightsByDurationRange(float minDur, float maxDur)
    {
        cout << "\nFlights with duration between " << minDur << " and " << maxDur << " hours:\n";
        ShowByDurationRange(root, minDur, maxDur);
    }
};

// ----------------------- MAIN PROGRAM -----------------------
int main()
{
    BST tree;
    int choice;

    do {
        cout << "\n--- Flight Reservation Directory ---\n";
        cout << "1. Insert new flight record\n";
        cout << "2. Delete a flight record\n";
        cout << "3. Search for a flight\n";
        cout << "4. Display all flights (sorted by Flight ID)\n";
        cout << "5. Display flights grouped by destination\n";
        cout << "6. Display flights grouped by status\n";
        cout << "7. Display ETA and punctuality status\n";
        cout << "8. Display flights within duration range (Surprise Feature)\n";
        cout << "9. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1)
        {
            Flight f;
            int id;
            string dest, dep, stat;
            float dur;
            cout << "Enter Flight ID: ";
            cin >> id;
            cin.ignore();
            cout << "Enter Destination: ";
            getline(cin, dest);
            cout << "Enter Departure Time (HH:MM): ";
            getline(cin, dep);
            cout << "Enter Flight Duration (hours): ";
            cin >> dur;
            cin.ignore();
            cout << "Enter Status (Departed/Landed/Delayed): ";
            getline(cin, stat);

            f.SetFlight(id, dest, dep, dur, stat);
            Node* n = new Node(f);
            tree.Insert(n);
            cout << "Flight inserted successfully.\n";
        }

        else if (choice == 2)
        {
            int id;
            cout << "Enter Flight ID to delete: ";
            cin >> id;
            Node* n = tree.Search(tree.getRoot(), id);
            if (n != NULL)
            {
                tree.Delete(n);
                cout << "Flight deleted successfully.\n";
            }
            else
                cout << "Flight not found.\n";
        }

        else if (choice == 3)
        {
            int id;
            cout << "Enter Flight ID to search: ";
            cin >> id;
            Node* n = tree.Search(tree.getRoot(), id);
            if (n != NULL)
                n->key.ShowFlight();
            else
                cout << "Flight not found.\n";
        }

        else if (choice == 4)
            tree.DisplayAll();

        else if (choice == 5)
        {
            string dest;
            cin.ignore();
            cout << "Enter Destination: ";
            getline(cin, dest);
            tree.ShowByDestination(dest);
        }

        else if (choice == 6)
        {
            string stat;
            cin.ignore();
            cout << "Enter Status (Departed/Landed/Delayed): ";
            getline(cin, stat);
            tree.ShowByStatus(stat);
        }

        else if (choice == 7)
            tree.ShowETA();

        else if (choice == 8)
        {
            float minDur, maxDur;
            cout << "Enter Minimum Duration (hours): ";
            cin >> minDur;
            cout << "Enter Maximum Duration (hours): ";
            cin >> maxDur;
            tree.ShowFlightsByDurationRange(minDur, maxDur);
        }

    } while (choice != 9);

    cout << "Exiting program...\n";
    return 0;
}