#include <iostream>
#include <cctype>
#include <string>
using namespace std;

// ItemType class to make stack reusable
class ItemType {
private:
    char data;

public:
    // Default constructor
    ItemType() {
        data = '\0';
    }
    
    // Parameterized constructor
    ItemType(char value) {
        data = value;
    }
    
    // Copy constructor
    ItemType(const ItemType& other) {
        data = other.data;
    }
    
    // Assignment operator
    ItemType& operator=(const ItemType& other) {
        if (this != &other) {
            data = other.data;
        }
        return *this;
    }
    
    // Assignment operator for char
    ItemType& operator=(char value) {
        data = value;
        return *this;
    }
    
    // Getter method
    char getValue() const {
        return data;
    }
    
    // Setter method - explicit way to set value
    void setValue(char value) {
        data = value;
    }
    
    // Conversion operator to char (most important for this application)
    operator char() const {
        return data;
    }
    
    // Equality operator for char (needed for comparisons)
    bool operator==(char value) const {
        return data == value;
    }
    
    // Inequality operator for char (needed for comparisons)
    bool operator!=(char value) const {
        return data != value;
    }
};

// Stack ADT using array-based implementation with ItemType
class Stack {
private:
    int top;
    int capacity;
    ItemType* arr;  // Array of ItemType objects

public:
    // Constructor
    Stack(int size) {
        capacity = size;
        arr = new ItemType[capacity];
        top = -1;
    }
    
    // Destructor
    ~Stack() {
        delete[] arr;
    }
    
    // Push operation
    void push(char c) {
        if (top == capacity - 1) {
            cout << "Stack overflow!" << endl;
            return;
        }
        arr[++top] = ItemType(c);  // Create ItemType object
    }
    
    // Pop operation
    char pop() {
        if (top == -1) {
            return '\0'; // empty stack indicator
        }
        return arr[top--].getValue();  // Get char value from ItemType
    }
    
    // Peek operation
    char peek() {
        if (top == -1) return '\0';
        return arr[top].getValue();  // Get char value from ItemType
    }
    
    // Check if stack is empty
    bool isEmpty() {
        return top == -1;
    }
    
    // Display current stack contents (for debugging) - Should be removed in production
    // void display() {
    //     cout << "Stack: ";
    //     for (int i = 0; i <= top; i++) {
    //         cout << arr[i].getValue() << " ";
    //     }
    //     cout << endl;
    // }
};

// Function to determine operator precedence
int precedence(char op) {
    if (op == '^')
        return 3;  // Highest precedence
    else if (op == '*' || op == '/')
        return 2;  // Medium precedence
    else if (op == '+' || op == '-')
        return 1;  // Lowest precedence
    else
        return -1; // Not an operator
}

// Function to check if character is an operator
bool isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}

// Function to convert infix to postfix notation
string infixToPostfix(string infix) {
    Stack s(infix.length());
    string postfix = "";
    
    for (int i = 0; i < infix.length(); i++) {
        char c = infix[i];
        
        if (isalnum(c)) {
            // Operand: directly add to output
            postfix += c;
        }
        else if (c == '(') {
            // Left parenthesis: push to stack
            s.push(c);
        }
        else if (c == ')') {
            // Right parenthesis: pop until left parenthesis
            while (!s.isEmpty() && s.peek() != '(') {
                char op = s.pop();
                postfix += op;
            }
            if (!s.isEmpty()) {
                s.pop(); // Remove the '('
            }
        }
        else if (isOperator(c)) {
            // Operator: handle based on precedence
            while (!s.isEmpty() && s.peek() != '(' && precedence(c) <= precedence(s.peek())) {
                char op = s.pop();
                postfix += op;
            }
            s.push(c);
        }
    }
    
    // Pop remaining operators from stack
    while (!s.isEmpty()) {
        char op = s.pop();
        postfix += op;
    }
    
    return postfix;
}

// Function to convert infix to prefix notation
// Algorithm: reverse infix, swap parentheses, convert to postfix, then reverse result
string infixToPrefix(string infix) {
    // Step 1: Reverse the infix expression and swap parentheses
    string reversed = "";
    for (int i = infix.length() - 1; i >= 0; i--) {
        if (infix[i] == '(') 
            reversed += ')';
        else if (infix[i] == ')') 
            reversed += '(';
        else 
            reversed += infix[i];
    }
    
    // Step 2: Convert the modified expression to postfix
    // But we need to modify the precedence rule for prefix conversion
    Stack s(reversed.length());
    string temp_postfix = "";
    
    for (int i = 0; i < reversed.length(); i++) {
        char c = reversed[i];
        
        if (isalnum(c)) {
            temp_postfix += c;
        }
        else if (c == '(') {
            s.push(c);
        }
        else if (c == ')') {
            while (!s.isEmpty() && s.peek() != '(') {
                temp_postfix += s.pop();
            }
            if (!s.isEmpty()) {
                s.pop(); // Remove '('
            }
        }
        else if (isOperator(c)) {
            // For prefix, we use < instead of <= for precedence comparison
            // This ensures right associativity for operators of same precedence
            while (!s.isEmpty() && s.peek() != '(' && precedence(c) < precedence(s.peek())) {
                temp_postfix += s.pop();
            }
            s.push(c);
        }
    }
    
    while (!s.isEmpty()) {
        temp_postfix += s.pop();
    }
    
    // Step 3: Reverse the result to get prefix
    string prefix = "";
    for (int i = temp_postfix.length() - 1; i >= 0; i--) {
        prefix += temp_postfix[i];
    }
    
    return prefix;
}

// Function to validate infix expression
bool isValidInfix(string infix) {
    if (infix.empty()) {
        cout << "Error: Expression cannot be empty!" << endl;
        return false;
    }
    
    int parentheses_count = 0;
    bool lastWasOperator = true; // To check if expression starts with operand
    bool lastWasOperand = false;
    
    for (int i = 0; i < infix.length(); i++) {
        char c = infix[i];
        
        // Check for invalid characters
        if (!isalnum(c) && !isOperator(c) && c != '(' && c != ')') {
            cout << "Error: Invalid character '" << c << "' found at position " << i+1 << "!" << endl;
            cout << "Only alphanumeric characters and operators (+, -, *, /, ^) and parentheses are allowed." << endl;
            return false;
        }
        
        // Handle parentheses
        if (c == '(') {
            parentheses_count++;
            if (lastWasOperand) {
                cout << "Error: Missing operator before '(' at position " << i+1 << "!" << endl;
                return false;
            }
            lastWasOperator = true;
            lastWasOperand = false;
        }
        else if (c == ')') {
            parentheses_count--;
            if (lastWasOperator) {
                cout << "Error: Missing operand before ')' at position " << i+1 << "!" << endl;
                return false;
            }
            lastWasOperator = false;
            lastWasOperand = true;
        }
        // Handle operands
        else if (isalnum(c)) {
            if (lastWasOperand) {
                cout << "Error: Missing operator between operands at position " << i+1 << "!" << endl;
                return false;
            }
            lastWasOperator = false;
            lastWasOperand = true;
        }
        // Handle operators
        else if (isOperator(c)) {
            if (lastWasOperator) {
                cout << "Error: Consecutive operators found at position " << i+1 << "!" << endl;
                return false;
            }
            lastWasOperator = true;
            lastWasOperand = false;
        }
        
        // Check for mismatched parentheses during parsing
        if (parentheses_count < 0) {
            cout << "Error: Mismatched parentheses - extra ')' at position " << i+1 << "!" << endl;
            return false;
        }
    }
    
    // Final checks
    if (parentheses_count != 0) {
        if (parentheses_count > 0) {
            cout << "Error: Mismatched parentheses - missing " << parentheses_count << " closing parenthesis ')'!" << endl;
        } else {
            cout << "Error: Mismatched parentheses - extra closing parenthesis!" << endl;
        }
        return false;
    }
    
    if (lastWasOperator) {
        cout << "Error: Expression cannot end with an operator!" << endl;
        return false;
    }
    
    // Check if expression has at least one operator (single operand is not a valid infix expression)
    bool hasOperator = false;
    for (char c : infix) {
        if (isOperator(c)) {
            hasOperator = true;
            break;
        }
    }
    
    if (!hasOperator) {
        cout << "Error: Expression must contain at least one operator!" << endl;
        cout << "A single operand like '" << infix << "' is not a valid infix expression." << endl;
        return false;
    }
    
    return true;
}

// Main function
int main() {
    cout << "===============================================" << endl;
    cout << "    INFIX TO POSTFIX AND PREFIX CONVERTER    " << endl;
    cout << "===============================================" << endl;
    cout << "\nOperator Precedence (High to Low):" << endl;
    cout << "1. ^ (Exponentiation)" << endl;
    cout << "2. *, / (Multiplication, Division)" << endl;
    cout << "3. +, - (Addition, Subtraction)" << endl;
    cout << "4. Parentheses ( ) override precedence" << endl;
    cout << "\nNote: Use single characters for operands (a, b, c, etc.)" << endl;
    cout << "Valid expression format: operand operator operand" << endl;
    cout << "Examples: a+b, (a+b)*c, a+b*c^d" << endl;
    cout << "===============================================" << endl;
    
    string infix;
    bool validInput = false;
    
    // Keep asking for input until valid expression is entered
    while (!validInput) {
        cout << "\nEnter an infix expression: ";
        cin >> infix;
        
        cout << "\nValidating expression..." << endl;
        if (isValidInfix(infix)) {
            validInput = true;
            cout << "✓ Valid expression accepted!" << endl;
        } else {
            cout << "\n Invalid expression! Please check the syntax and try again." << endl;
            cout << "\nReminder:" << endl;
            cout << "- Use only letters/numbers as operands (a, b, 1, 2, etc.)" << endl;
            cout << "- Use only +, -, *, /, ^ as operators" << endl;
            cout << "- Ensure proper parentheses matching" << endl;
            cout << "- No consecutive operators or operands" << endl;
            cout << "- Expression should not start/end with operators" << endl;
        }
    }
    
    // Convert to postfix and prefix
    string postfix = infixToPostfix(infix);
    string prefix = infixToPrefix(infix);
    
    // Display results
    cout << "\n===============================================" << endl;
    cout << "                   RESULTS                    " << endl;
    cout << "===============================================" << endl;
    cout << "Infix   : " << infix << endl;
    cout << "Postfix : " << postfix << endl;
    cout << "Prefix  : " << prefix << endl;
    cout << "===============================================" << endl;
    
    return 0;
}